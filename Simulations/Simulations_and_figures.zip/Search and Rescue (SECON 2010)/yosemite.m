 clear all;

rand('state', 0);
randn('state', 0);

TAG_DENSITY = 10;
TAG_MEM = 7;

TRAIL_WIDTH = 1;
NUM_HIKERS = 25;
SCAN_RANGE = 1;
SCAN_FAIL_PROB = 0.25;
STEP_LEN = SCAN_RANGE;

% Create tag locations.
NUM_SECS = 14; % 1 to 9 are roads, 10 to 14 are junctions.
TRAIL_WIDTH = 1;
sec_lengths(1:9,1) = [ ...
    1600    1300    1600 ...
    2300    2100    0600 ...
    0300    1600    1600 ...
]';
sec_lengths(10:14,1) = TRAIL_WIDTH * ones(5,1);
% Generate tag locations for each section.  Tag locations are specified by
% section number and then tag number.
for (i = 1:NUM_SECS)
    num_tags(i,1) = round(TAG_DENSITY * TRAIL_WIDTH * sec_lengths(i));
    tag_locs_x(i,1:num_tags(i)) = rand(num_tags(i),1) * sec_lengths(i);
    tag_locs_y(i,1:num_tags(i)) = rand(num_tags(i),1) * TRAIL_WIDTH;
end
% Generate tag sequence numbers.
sn = zeros(NUM_SECS, NUM_HIKERS, max(num_tags));

% Enumerate all possible paths.  They are specified by sections and
% directions.
paths = [ ...
    01  10  05  13  08  14  07  12  04  00  00  00; ...
    01  10  02  11  06  13  08  14  09  00  00  00; ...
    04  12  07  14  08  13  06  11  02  10  01  00; ...
    04  12  03  11  02  10  05  13  08  14  09  00; ...
    09  14  08  13  05  10  01  00  00  00  00  00; ...
    09  14  08  13  06  11  03  12  04  00  00  00; ...
];
directs = [ ...
    01  00  01  00  01  00  -1  00  01  00  00  00; ...
    01  00  01  00  01  00  01  00  01  00  00  00; ...
    -1  00  01  00  -1  00  -1  00  -1  00  -1  00; ...
    -1  00  -1  00  -1  00  01  00  01  00  01  00; ...
    -1  00  -1  00  -1  00  -1  00  00  00  00  00; ...
    -1  00  -1  00  -1  00  01  00  01  00  00  00;
];

% Performance metrics relative to first hiker choosing path 1.
cum_dist_travelled = 0;
dist_travelled = zeros(NUM_HIKERS-1,1);
frac_ids_remain = zeros(NUM_HIKERS-1,1);
search_metrics = zeros(NUM_HIKERS-1,1);

curr_sn = 1;
for hiker = 1:NUM_HIKERS
    hiker
    seen_freqs = zeros(NUM_HIKERS,1);
    del_freqs = zeros(NUM_HIKERS,1);
    if (hiker == 1) path_index = 1;
    else path_index = ceil(rand()*length(paths(:,1))); end;
    path = paths(path_index,:);
    last_nz_index = find(path == 0, 1) - 1;
    path = path(1:last_nz_index);
    direct = directs(path_index,1:last_nz_index);
    
    % Step over each section.
    for i = 1:length(path)
        sec = path(i);
        sec_direct = direct(i);
        if (hiker ~= 1) cum_dist_travelled = cum_dist_travelled + sec_lengths(sec); end
        
        % Step over inside the section.
        if ( sec_direct == 1 )
            in = 0; incr = STEP_LEN; out = sec_lengths(sec);
        else
            in = sec_lengths(sec); incr = -STEP_LEN; out = 0;
        end
        for step = in:incr:out
            % Locate tags in range.  Throw away SCAN_FAIL_PROB of them.
            tag_indices = find( distance(step, TRAIL_WIDTH/2, tag_locs_x(sec,1:num_tags(sec)), tag_locs_y(sec,1:num_tags(sec))) < SCAN_RANGE );
            mask = rand(1,length(tag_indices)) > SCAN_FAIL_PROB;
            tag_indices = tag_indices(mask);
           
            % Go through those tags, assigning sequence numbers according
            % to the specific algorithms.
            for j = 1:length(tag_indices);
                tag = tag_indices(j);
                nz_indices = find( sn(sec, :, tag) );
                seen_freqs( nz_indices ) = seen_freqs( nz_indices ) + 1;
                
                if (length(nz_indices) > TAG_MEM) display('Error.'); end;
                
                if ( length(nz_indices) < TAG_MEM )
                    % Do nothing.
                elseif( sn(sec,hiker,tag) ~= 0)
                    % Do nothing.  Just increase SN.
                else % Use an algorithm.
                
                    % RS
                    del_hiker = nz_indices( ceil(rand()*TAG_MEM) );
                    % OS
                    [dummy, min_index] = min( sn(sec, nz_indices, tag) );
                    del_hiker = nz_indices(min_index);                                      
                    % HFS
                    [dummy, max_index] = max(seen_freqs(nz_indices));
                    del_hiker = nz_indices(max_index);
                    % LDFS
                    [dummy, min_index] = min(del_freqs(nz_indices));
                    del_hiker = nz_indices(min_index);
                                       
                    del_freqs(del_hiker) = del_freqs(del_hiker) + 1;
                    sn(sec, del_hiker, tag) = 0;
                  
                end
                curr_sn = curr_sn + 1;
                sn(sec, hiker, tag) = curr_sn;
                
            end % for j
 
        end % for step
        
    end % for i
    
    if (hiker == 1)
        num_ids_begin = nnz( sn(:,1,:) );
    end
    
    if (hiker ~= 1)
        dist_travelled(hiker-1) = cum_dist_travelled;
        num_ids_end = nnz( sn(:,1,:) );
        frac_ids_remain(hiker-1) = num_ids_end / num_ids_begin;
        
        % Calculate search time metric.
        cum_search_metric = 0;
        for sec = [1    10     5    13     8    14     7    12     4 ]
            dims = size(sn);
            tag_sns = reshape( sn(sec,1,:), dims(3), 1 );
            [dummy, sort_indices] = sort(tag_sns);
            nz_part_begin = find( tag_sns(sort_indices), 1);
            in_order_tags = sort_indices(nz_part_begin:end);
  
            for i = 1:length(in_order_tags)-1
                cum_search_metric = cum_search_metric + ... 
                distance(tag_locs_x(sec,in_order_tags(i)),   tag_locs_y(sec,in_order_tags(i)), ...
                         tag_locs_x(sec,in_order_tags(i+1)), tag_locs_y(sec,in_order_tags(i+1)) ).^2;  
            end % for i
            
        end % for sec
        search_metrics(hiker-1) = cum_search_metric * pi;
        
    end
    
end % for hiker

dist_travelled
format long;
frac_ids_remain
format bank
search_metrics

