 clear all;

rand('state', 0);
randn('state', 0);

TAG_DENSITY = 1;
TAG_MEM = 10;
NUM_HIKERS = 20;
TRAIL_WIDTH = 1;
STEP_LEN = 1;
SCAN_RANGE = 1; 
SCAN_FAIL_PROB = 0.2;

% Create tag locations.
NUM_SECS = 22; % 1 to 14 are roads, 15 to 22 are junctions.
TRAIL_WIDTH = 1;
sec_lengths(1:14,1) = [ ...
    10  10  10  10  10  10  10 ...  
    05  10  10  10  10  10  10 ]';
sec_lengths(15:22,1) = TRAIL_WIDTH * ones(8,1);
% Generate tag locations for each section.  Tag locations are specified by
% section number and then tag number.
for (i = 1:NUM_SECS)
    num_tags(i,1) = round(TAG_DENSITY * TRAIL_WIDTH * sec_lengths(i));
    tag_locs_x(i,1:num_tags(i)) = rand(num_tags(i),1) * sec_lengths(i);
    tag_locs_y(i,1:num_tags(i)) = rand(num_tags(i),1) * TRAIL_WIDTH;
end
% Generate tag sequence numbers.
sn = zeros(NUM_SECS, NUM_HIKERS, max(num_tags));

% Enumerate all possible paths.  They are specified by sections and
% directions.
paths = [ ...
    01  15  02  16  06  19  09  20  13  22  14  00  00  00  00  00; ...
    01  15  05  18  08  19  09  20  10  21  11  00  00  00  00  00; ...
    04  17  03  16  02  15  05  18  08  19  09  20  10  21  11  00; ...
    04  17  03  16  06  19  08  18  12  22  14  00  00  00  00  00; ...
    11  21  10  20  09  19  08  18  05  15  01  00  00  00  00  00; ...
    11  21  07  17  03  16  06  19  09  20  13  22  14  00  00  00; ...
    14  22  13  20  09  19  08  18  05  15  01  00  00  00  00  00; ...
    14  22  12  18  08  19  06  16  03  17  04  00  00  00  00  00; ...
];
directs = [ ...
    1   0   1   0   1   0   1   0   1   0   1   0   0   0   0   00; ...
    1   0   1   0   1   0   1   0   1   0   1   0   0   0   0   00; ...
    -1  0   -1  0   -1  0   1   0   1   0   1   0   1   0   1   00; ...
    -1  0   -1  0   1   0   -1  0   1   0   1   0   0   0   0   00; ...
    -1  0   -1  0   -1  0   -1  0   -1  0   -1  0   0   0   0   00; ...
    -1  0   -1  0   -1  0   1   0   1   0   1   0   1   0   0   00; ...
    -1  0   -1  0   -1  0   -1  0   -1  0   -1  0   0   0   0   00; ...
    -1  0   -1  0   1   0   -1  0   1   0   1   0   0   0   0   00; ...
];

% Performance metrics relative to first hiker choosing path 1.
for hiker = 1:NUM_HIKERS
    seen_freqs = zeros(NUM_HIKERS,1);
    del_freqs = zeros(NUM_HIKERS,1);
    curr_sn = 1;
    if (hiker == 1) path_index = 1;
    else path_index = ceil(rand()*length(paths(:,1))); end;
    path = paths(path_index,:);
    last_nz_index = find(path == 0, 1) - 1;
    path = path(1:last_nz_index);
    direct = directs(path_index,1:last_nz_index);
    
    % Step over each section.
    for i = 1:length(path)
        sec = path(i);
        sec_direct = direct(i);
        
        % Step over inside the section.
        if ( sec_direct == 1 )
            in = 0; incr = STEP_LEN; out = sec_lengths(sec);
        else
            in = sec_lengths(sec); incr = -STEP_LEN; out = 0;
        end
        for step = in:incr:out
            % Locate tags in range.  Throw away SCAN_FAIL_PROB of them.
            tag_indices = find( distance(step, TRAIL_WIDTH/2, tag_locs_x(sec,1:num_tags(sec)), tag_locs_y(sec,1:num_tags(sec))) < SCAN_RANGE );
            mask = rand(1,length(tag_indices)) > SCAN_FAIL_PROB;
            tag_indices = tag_indices(mask);
           
            % Go through those tags, assigning sequence numbers according
            % to the specific algorithms.
            for j = 1:length(tag_indices);
                tag = tag_indices(j);
                nz_indices = find( sn(sec, :, tag) );
                seen_freqs( nz_indices ) = seen_freqs( nz_indices ) + 1;
                
                if ( length(nz_indices) < TAG_MEM )
                    % Do nothing.
                else % Use an algorithm.
                
                    % OS
                    [dummy, min_index] = min( sn(sec, nz_indices, tag) );
                    del_hiker = nz_indices(min_index);                                      
                    % RS
                    del_hiker = nz_indices( ceil(rand()*TAG_MEM) );
                    % HFS
                    [dummy, max_index] = max(seen_freqs(nz_indices));
                    del_hiker = nz_indices(max_index);
                    % LDFS
                    [dummy, min_index] = min(del_freqs(nz_indices));
                    del_hiker = nz_indices(min_index);
                                       
                    del_freqs(del_hiker) = del_freqs(del_hiker) + 1;
                    sn(sec, del_hiker, tag) = 0;
                  
                end
                curr_sn = curr_sn + 1;
                sn(sec, hiker, tag) = curr_sn;
                
            end % for j
 
        end % for step
        
        
    end % for i
    
end % for hiker