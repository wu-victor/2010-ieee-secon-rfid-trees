function out = distance(points_x1, points_y1, points_x2, points_y2)

    out = sqrt( (points_x1 - points_x2).^2 + (points_y1 - points_y2).^2 );

return;